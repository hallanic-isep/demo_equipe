extends CharacterBody2D


@export var max_health: int = 200
@export var speed: float = 80.0
@export var contact_damage: int = 20
@export var attack_cooldown: float =1.0

var health: int
var player: Node2D = null
var attack_timer: float = 0.0

func _ready() -> void:
	health = max_health
	var players = get_tree().get_nodes_in_group("player")
	if players.size() > 0:
		player = players[0] as Node2D
	add_to_group("enemy")

func _physics_process(delta: float) -> void:
	if attack_timer > 0.0:
		attack_timer -= delta
		
	if player == null or not is_instance_valid(player):
		velocity = Vector2.ZERO
		move_and_slide()
		return
		
	var dir: Vector2 = (player.global_position - global_position).normalized()
	velocity = dir *speed
	move_and_slide()
	
	_check_contact_attack()
	
func _check_contact_attack() -> void:
	if attack_timer > 0.0:
		return
	
	var slide_count := get_slide_collision_count()
	for i in range(slide_count):
		var collision := get_slide_collision(i)
		var body := collision.get_collider()
		
		if body == null:
			continue
		if body.has_method("take damage"):
			body.take_damage(contact_damage)
			attack_timer	 = attack_cooldown
			break

func take_damage(amount:int) -> void:
	health -=amount
	if health <= 0:
		die()
		
func die() -> void:
	print("Boss defeated")
	get_tree().call_group("game_manager","on_boss_defeated")
	queue_free()
	
	
	
