extends Node2D

@export var inside_width: int
@export var inside_height : int


# Replace walls with doors
func north():
	$"North Door".visible = true
	$NorthWall.queue_free()

func south():
	$"South Door".visible = true
	$SouthWall.queue_free()
	
func east():
	$"East Door".visible = true
	$EastWall.queue_free()
	
func west():
	$"West Door".visible = true
	$WestWall.queue_free()
