extends CharacterBody2D

@export var speed:=200
@export var max_health := 100
var health := max_health

@export var projecttile_scene: PackedScene

"""

func _move(delta):
	var dir = Vector2.ZERO
	dir.x = Input.get_action_strength(KEY_RIGHT) - Input.get_action_strength(KEY_LEFT)
	dir.y = Input.get_action_strength(KEY_DOWN) - Input.get_action_strength(KEY_UP)
	velocity = dir.normalized()*speed
	move_and_slide()
	
func	 _attack():
	if projecttile_scene == null:
		return
	
	vr_bread = project_scene.instantiate()
	bread.global_postition = global_position
	
	var mouse_pos = get_global_mouse_position()
	bread.direction = (mouse_pos - global_position).normalized()
	
	get_tree().current_scene.add_child(bread)

func take_damage(amount):
	health -= amount
	if health <= 0:
		die()

func die():
	print("Player has died.")
	get_tree().call_group("game_manager","on_player_dead")
	queue_free()

func heal(amount):
	health = min(health + amount, max_health)
	
func _physics_process(delta: float) -> void:
	move(delta)
	if Input.is_action_just_pressed("attack"):
		attack()
"""
