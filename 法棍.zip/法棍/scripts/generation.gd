extends Node2D

# ------------------------------------------------------------------------
# CONFIGURATION
# ------------------------------------------------------------------------

@export var map_width: int = 7
@export var map_height: int = 7
@export var rooms_to_generate: int = 12
@export var room_scene: PackedScene

const ROOM_SIZE := 816
const HALF_ROOM := ROOM_SIZE / 2

# ------------------------------------------------------------------------
# RUNTIME VARIABLES
# ------------------------------------------------------------------------

var map: Array = []
var room_nodes: Array = []
var rooms_instantiated := false
var room_count := 0
var first_room_pos: Vector2i = Vector2i(3, 3)

# ------------------------------------------------------------------------
# READY
# ------------------------------------------------------------------------

func _ready():
	print("Dungeon generator ready!")

	# Check room_scene assignment
	if not room_scene:
		push_error("room_scene NOT assigned! Assign your Room.tscn in the Inspector.")
		return

	# Initialize map
	map.clear()
	for x in range(map_width):
		map.append([])
		for y in range(map_height):
			map[x].append(false)

	randomize()
	generate_dungeon()


# ------------------------------------------------------------------------
# DUNGEON GENERATION
# ------------------------------------------------------------------------

func generate_dungeon():
	print("Starting dungeon generation...")
	generate_room(first_room_pos.x, first_room_pos.y)
	instantiate_rooms()
	print("Dungeon generation complete. Rooms instantiated: ", room_nodes.size())

	# Temporarily skip player placement to avoid errors
	# var room_pos: Vector2 = Vector2(first_room_pos.x, first_room_pos.y) * ROOM_SIZE
	# $"../Player".global_position = room_pos + Vector2(HALF_ROOM, HALF_ROOM)

	calculate_key_and_exit()


# ------------------------------------------------------------------------
# RECURSIVE ROOM GENERATION
# ------------------------------------------------------------------------

func generate_room(x: int, y: int):
	if room_count >= rooms_to_generate:
		return

	if x < 0 or x >= map_width or y < 0 or y >= map_height:
		return

	if map[x][y]:
		return

	# Mark the room
	map[x][y] = true
	room_count += 1
	print("Generated room at: ", x, ",", y, " (total rooms: ", room_count, ")")

	# Save first room position
	if room_count == 1:
		first_room_pos = Vector2i(x, y)

	# Randomize directions
	var directions = [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]
	directions.shuffle()

	for dir in directions:
		var nx = x + int(dir.x)
		var ny = y + int(dir.y)
		if randf() < 0.7:  # 70% chance to generate neighbor
			generate_room(nx, ny)


# ------------------------------------------------------------------------
# ROOM INSTANTIATION
# ------------------------------------------------------------------------
func instantiate_rooms():
	if rooms_instantiated:
		return
	rooms_instantiated = true

	# Center offset so dungeon appears around (0,0)
	var offset = Vector2(map_width, map_height) * ROOM_SIZE / 2

	for x in range(map_width):
		for y in range(map_height):
			if not map[x][y]:
				continue  # No room here

			if not room_scene:
				push_error("Room scene not assigned in dungeon generator!")
				return

			var room = room_scene.instantiate()
			room.position = Vector2(x, y) * ROOM_SIZE - offset
			add_child(room)
			room_nodes.append(room)
			print("Instantiated room at: ", room.position)

			# ----------------------------
			# Open doors based on neighbors
			# ----------------------------
			if y > 0 and map[x][y - 1]:
				if room.has_method("north"):
					room.north()
			if y < map_height - 1 and map[x][y + 1]:
				if room.has_method("south"):
					room.south()
			if x > 0 and map[x - 1][y]:
				if room.has_method("west"):
					room.west()
			if x < map_width - 1 and map[x + 1][y]:
				if room.has_method("east"):
					room.east()

			# Generate content for non-first rooms
			if Vector2i(x, y) != first_room_pos and room.has_method("generate"):
				room.generate()

# ------------------------------------------------------------------------
# KEY AND EXIT PLACEHOLDER
# ------------------------------------------------------------------------

func calculate_key_and_exit():
	pass
