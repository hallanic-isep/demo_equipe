extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$StartButton.pressed.connect(on_start_button_pressed)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	get_tree().change_scene_to_file("res://scenes/Game.tscn")
