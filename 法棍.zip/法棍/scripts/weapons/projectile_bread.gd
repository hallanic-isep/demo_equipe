extends Area2D

@export var speed: float = 400
@export var damage: int =20
@export var lifetime: float = 2.0

var  direction: Vector2 = Vector2.ZERO
"""
func _ready() :
	body_entered.connect(on_body_entered)
	
	await get_tree().create_timer(lifetime).timeout
	queue_free()

func _physics_process(delta: float) -> void:
	if direction == Vector2.ZERO:
		return
	position +=direction.normalized()*speed*delta
	
func _on_body_entered(body : Node) -> void:
	if body == null:
		return
	
	if body.has_method("take_damage"):
		body.take_damage(damage)
		queue_free()
		
"""
